﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class GenerateQRCode : System.Web.UI.Page
    {
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {

            }
            else
            {
              //  resetAll();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnGenerate_Click(object sender, EventArgs e)
        {
            ////Get Upload path Server location file .
            string path = Server.MapPath("~/Images/");

            ////Check path("~/Images/") exists on Server locationor else create new one .
            if (!Directory.Exists(path))
            {
                //// create new path "~/Images/".
                Directory.CreateDirectory(path);
            }

            ////Check has file exists if yes then ok else go out .
            if (FileUpload1.PostedFile != null)
            {
                ////Use Namespace called :  System.IO  
                string FileName = Path.GetFileNameWithoutExtension(FileUpload1.PostedFile.FileName);

                ////To Get File Extension  
                string FileExtension = Path.GetExtension(FileUpload1.PostedFile.FileName);

                ////Add Current Date To Attached File Name  
                FileName =txtName.Text +"-" + DateTime.Now.ToString("yyyyMMdd") + "-" + FileName.Trim() + FileExtension;

                ////Its Create complete path to store in server.  
                string ImagePath = path + FileName;

                ////To copy and save file into server.  
                FileUpload1.PostedFile.SaveAs(ImagePath);


                // Call Method generte barcode 
                GenerateCode(txtName.Text, ImagePath);
            }
        }

        /// <summary>
        /// button click read barcode 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRead_Click(object sender, EventArgs e)
        {
            
                string rdpath = Session["readqrPath"].ToString();
                //cal method read barcode 
                ReadBarcode(rdpath);
            
           
        }

        /// <summary>
        /// generate bar code 
        /// </summary>
        private void GenerateCode(string name, string path)
        {
            string size = "150x150";
            string apiUrl = "https://api.qrserver.com/v1/create-qr-code/?data='" + name + "'&Size=" + size +"' &fileurl=" + path;
          
            var input = "{\"data\":'"+name+"'}";

            string inputJson = (new JavaScriptSerializer()).Serialize(input);
            HttpClient client = new HttpClient();

            HttpContent inputContent = new StringContent(inputJson, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.GetAsync(apiUrl).Result;
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStreamAsync().Result;
                var bitmapimg = new Bitmap(result);

                using (MemoryStream ms = new MemoryStream())
                {
                    bitmapimg.Save(ms, ImageFormat.Png);
                    Byte[] b = ms.ToArray();
                    imgQRCode.Visible = true;
                    imgQRCode.ImageUrl = @"data:image/png;base64," + Convert.ToBase64String(b);
                    Session["readqrPath"] = "https://api.qrserver.com/v1/create-qr-code/?data='" + name;
                }

            }
        }

        /// <summary>
        /// read barcode 
        /// </summary>
        /// <param name="path"></param>
        private void ReadBarcode(string path)
        {
            string str = "Rahul";
            string apiUrl = "https://api.qrserver.com/v1/read-qr-code/?fileurl=" + path;
            var input = new
            {
                path = str,
            };
            string inputJson = (new JavaScriptSerializer()).Serialize(input);
            HttpClient client = new HttpClient();
            HttpContent inputContent = new StringContent(inputJson, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.GetAsync(apiUrl).Result;
            if (response.IsSuccessStatusCode)
            {
                
                var result = response.Content.ReadAsStringAsync().Result;
                lblQRCode.Text = result;
                
            }
           
        }

        /// <summary>
        /// clear all vaalues 
        /// </summary>
        private void resetAll()
        {
            txtName.Text = "";
            imgQRCode.ImageUrl = "";
            lblQRCode.Text = "";
            Session.RemoveAll();
        }

    }
}